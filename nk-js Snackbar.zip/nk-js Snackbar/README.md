Hello World !!

Wellcome to nk-js SnackBar help docs .

nk-js SnackBar from CodinoDevsIr in 2023.

# What is nk-js?

nk-js is a library for creating and making a snack bar for the website, which is completely responsive, this library gives an update every month, and in each update, new features are added to this library, and everyone can use it. Soon this library will be expanded to be used in other frameworks. In the following, we will learn to work with this library....

 To work with this library, you must have an HTML file and a JavaScript file
 as below :

        = index.html
        = main.js

<----------------------------------------------------------------------------------------------------------------------------------------------->

Create the structure of the site page in the HTML file and link the JavaScript and CSS nk-js file in it.
as below:

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>nk-js</title>
    <link rel="stylesheet" href="css/nk.css">
</head>

<body>
    <script src="js/nk.js"></script>
</body>

</html>

You can use nk-js cdn to link your web file:

<script src="https://codinodevs.ir/nk-js/@1.0.1/js/nk.js"></script>
<link rel="stylesheet" href="https://codinodevs.ir/nk-js/@1.0.1/css/nk.css">

# Attention ! This method may slow down your site

To continue, you need to link your JavaScript file after the nk-js JavaScript file
as below:

        <!DOCTYPE html>
        <html lang="en">

        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>nk-js</title>
            <link rel="stylesheet" href="https://codinodevs.ir/nk-js/@1.0.1/css/nk.css">
        </head>

        <body>
            <script src="https://codinodevs.ir/nk-js/@1.0.1/js/nk.js"></script>
    =====>  <script src="main.js"></script>
        </body>

        </html>

# After this work, the work environment for making snack bar is ready

To build the main structure of the snack bar, we must use a div with the nk-snackbar class, as shown below:

<div class="nk-snackbar">

</div>

The job of this div is to create the main structure of the snack bar.

    To continue:


    In the nk-js library, the snack bar is divided into two parts.

        1 - Confirm button section
        2- Message text section

    To create the structure of these two sections, we must create two divs.

    The class used for the confirmation button div is nk-submit-box, which creates the main box of this part, but this is not the end of the work because there is still a second box left.

    To create the box of the second part, we need to create a div with the nk-msg-box class

    to make the second box as well

    So far, the general structure of the snack bar has been created on the page.

Example :

<div class="nk-snackbar">
<div class="nk-submit-box">

</div>
<div class="nk-msg-box">

</div>
</div>

until now :

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>nk-js</title>
    <link rel="stylesheet" href="https://codinodevs.ir/nk-js/@1.0.1/css/nk.css">
</head>

<body>

<div class="nk-snackbar">
<div class="nk-submit-box">

</div>
<div class="nk-msg-box">

</div>
</div>
<script src="https://codinodevs.ir/nk-js/@1.0.1/js/nk.js"></script>
<script src="main.js"></script>
</body>

</html>

To create the message text, we use a p tag and give it the nk-msg class and write our desired message.

To create a button, we must use the p tag and give it the nk-submit class to create the button

By now, the entire structure of the snack bar is already known, and it is enough to write a few lines of JavaScript code to use it.

Example :

<div class="nk-snackbar">
<div class="nk-submit-box">
<p class="nk-submit">OK</p>
</div>
<div class="nk-msg-box">
<p class="nk-msg">Lorem ipsum dolor sit amet consectetur.</p>
</div>
</div>