let btn = document.querySelector(".btn").addEventListener("click", function() {
    nk_snackbar({
        Time: 2000,
        Animation: true
    });
});